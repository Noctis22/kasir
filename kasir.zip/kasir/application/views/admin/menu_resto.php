<section class="content">
	<div class="container-fluid">
		<div class="block-header"><h2>MENU RESTORAN</h2></div>
		<div class="row clearfix">
			<div class="col-md-12">
				<div class="card">
					<div class="header">
						<div class="pull-left"><i class="fa fa-fw fa-calendar-minus-o"></i> Table menu restoran</div>
						<div class="pull-right">
							<a href="javascript:void(0)" class="btn bg-pink btn-sm waves-effect" data-toggle="modal" data-target="#tambah-menu"><i class="fa fa-fw fa-plus"></i> Tambah menu</a>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="body">
						<table class="table table-hovered table-bordered table-menu" width="100%">
							<thead>
								<tr>
									<th>Menu</th>
									<th>Harga (Rp)</th>
									<th>Action</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody></tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>